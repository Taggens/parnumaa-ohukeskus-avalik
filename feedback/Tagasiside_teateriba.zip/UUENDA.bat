@echo off
cd /d "%~dp0"
py update_notice.py
pause
