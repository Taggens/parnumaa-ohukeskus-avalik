function installFeedbackMenu() {
  const anchor=document.querySelector('.nav-link[data-section="settings"]');
  const button=document.createElement('button');
  button.type='button';button.className='nav-link';button.dataset.section='feedback';
  button.textContent='✉ Tagasiside';anchor.before(button);
  const panel=document.createElement('section');
  panel.className='screen';panel.id='feedback';
  panel.innerHTML='<article class="panel"><h2>Tagasiside</h2><label>Leht <select></select></label> <label>Teema <select></select></label> <label>Järjestus <select><option>Uuemad enne</option><option>Vanemad enne</option></select></label> <button type="button">Värskenda</button><p role="status"></p><div></div></article>';
  document.querySelector('.screen').parentElement.append(panel);
  const [page,topic,order]=panel.querySelectorAll('select');
  const status=panel.querySelector('p'),list=panel.querySelector('article > div');
  let rows=[];
  const overview=document.getElementById('overview');
  const notice=document.createElement('button');
  notice.type='button';
  notice.hidden=true;
  notice.style.cssText='background:#183b40;color:#cbfff3;border:1px solid #508980;border-radius:10px;padding:12px 16px;margin-bottom:12px;text-align:left;cursor:pointer;font:inherit';
  overview.prepend(notice);
  const cursorKey='parnu-feedback-seen:'+userAccount;
  let seen=null,loading=false,lastChecked=0;
  function readCursor(){
    try{
      const value=localStorage.getItem(cursorKey);
      if(value!==null && Number.isFinite(Number(value)))seen=Math.max(seen||0,Number(value));
    }catch{}
  }
  function remember(time){
    seen=Math.max(seen||0,time);
    try{localStorage.setItem(cursorKey,String(seen));}catch{}
  }
  function updateNotice(){
    readCursor();
    const times=rows.map(r=>Date.parse(r[0])).filter(Number.isFinite);
    const latest=times.reduce((a,b)=>Math.max(a,b),0);
    if(seen===null || (panel.classList.contains('active') && !document.hidden && !page.value && !topic.value))remember(latest);
    const count=times.filter(t=>t>seen).length;
    notice.hidden=count===0;
    notice.textContent=count===1?'✉ 1 uus tagasisidesõnum · Ava':('✉ '+count+' uut tagasisidesõnumit · Ava');
  }
  function poll(){
    if(!document.hidden && overview.classList.contains('active') && Date.now()-lastChecked>=60000)refresh();
  }
  function render(){
    list.replaceChildren();
    const matches=rows.filter(r=>(!page.value||r[1]===page.value)&&(!topic.value||r[2]===topic.value));
    matches.sort((a,b)=>(Date.parse(b[0])-Date.parse(a[0]))*(order.selectedIndex?-1:1));
    status.textContent=matches.length+' sõnumit';
    for(const [time,place,theme,message] of matches){
      const item=document.createElement('article'),title=document.createElement('strong'),body=document.createElement('p');
      title.textContent=[localTime(time,true),place,theme].join(' · ');
      body.textContent=message;body.style.whiteSpace='pre-wrap';body.style.overflowWrap='anywhere';
      item.append(title,body);list.append(item);
    }
  }
  async function refresh(){
    if(loading)return;
    loading=true;
    lastChecked=Date.now();
    try{
      const data=await requestJSON('/api/feedback');
      if(!Array.isArray(data))throw Error();
      rows=data;
      for(const [select,idx] of [[page,1],[topic,2]]){
        const prev=select.value;
        select.replaceChildren(new Option('Kõik',''));
        for(const value of [...new Set(rows.map(row=>row[idx]))].sort())select.add(new Option(value,value));
        if([...select.options].some(o=>o.value===prev))select.value=prev;
      }
      render();updateNotice();
    }catch{status.textContent='Sõnumeid ei õnnestunud laadida. Kontrolli vastuvõtja seadistust.';}finally{loading=false;}
  }
  for(const select of [page,topic,order])select.addEventListener('change',render);
  notice.onclick=()=>{
    page.value='';topic.value='';button.click();
  };
  new MutationObserver(poll).observe(overview,{attributes:true,attributeFilter:['class']});
  window.addEventListener('storage',event=>{if(event.key===cursorKey && seen!==null)updateNotice();});
  document.addEventListener('visibilitychange',poll);
  setInterval(poll,60000);
  refresh();
  panel.querySelector('button').onclick=refresh;
  button.onclick=()=>{go('feedback');text('page-title','Tagasiside');refresh();};
}
