from pathlib import Path
import shutil
import tempfile

def update(root):
    path=root/'app.js'
    here=Path(__file__).resolve().parent
    data=path.read_bytes()
    old=(here/'previous.js').read_text(encoding='utf-8').strip()
    new=(here/'admin.js').read_text(encoding='utf-8').strip()
    for sep in ['\r\n','\n']:
        before=old.replace('\n',sep).encode()
        after=new.replace('\n',sep).encode()
        if after in data:return 'Uuendus on juba paigaldatud.'
        if data.count(before)==1:
            backup=root/'app.js.before-feedback-notice'
            if not backup.exists():shutil.copy2(path,backup)
            with tempfile.NamedTemporaryFile(dir=root,delete=False) as f:
                f.write(data.replace(before,after,1))
            Path(f.name).replace(path)
            return 'Uuendus paigaldatud. Vajuta adminilehel Ctrl+F5.'
    raise ValueError('Sellest app.js failist ei leitud varasemat tagasisidemenüüd. Kontrolli serverikausta.')

if __name__=='__main__':
    root=Path(input('Adminiserveri kaust (server.py asukoht): ').strip().strip('"'))
    print(update(root))
